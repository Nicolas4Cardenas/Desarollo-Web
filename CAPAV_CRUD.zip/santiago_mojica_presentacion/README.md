# PoliRestaurante · Capa de presentación (Santiago Mojica)

Versión súper sencilla: **login + Categorías (solo INSERTAR y LISTAR)**.

## Cómo correrlo

1. Tener MySQL con la base `poli_restaurante` ya creada (con `backend.sql`).
   No vuelvas a ejecutar el script si ya tienes datos.
2. En la carpeta del proyecto:
   ```cmd
   py -m venv .venv
   .venv\Scripts\activate.bat
   python -m pip install -r requirements.txt
   python app.py
   ```
3. Abre **http://127.0.0.1:5000** (Flask sirve la API y la página).

Usuario de prueba: `admin` / `Admin2026*`
(también `mesero1` / `Mesero2026*` y `cocina1` / `Cocina2026*`).

Pruebas (no necesitan MySQL): `python -m pytest -v`

## Qué mostrar al profesor

```
Navegador ─► frontend/js/model.js ─► POST /api/v1/login ─► rutas/auth.py ─► auth_dao
Navegador ─► frontend/js/model.js ─► GET  /api/v1/categorias ─► rutas/categorias.py
          ─► servicios/categoria_manager.py ─► categoria_dao (DAO 1) + producto_dao (DAO 2)
Navegador ─► frontend/js/model.js ─► POST /api/v1/categorias ─► categoria_manager.insertar ─► categoria_dao
```

- **Los 2 DAO en una función:** `api/servicios/categoria_manager.py`, función `listar()`
  llama a `categoria_dao` (DAO 1) y `producto_dao` (DAO 2) y combina el resultado.
- **MVC del frontend:** `model.js` (fetch), `view.js` (pinta), `controller.js` (eventos).

## Qué se agregó / cambió respecto al CRUD original

| Archivo | Cambio |
|---|---|
| `frontend/` | NUEVO: index.html, styles.css y js/ (model, view, controller, app, config) |
| `api/servicios/categoria_manager.py` | NUEVO: usa 2 DAO |
| `api/rutas/categorias.py` | `GET` y `POST` ahora pasan por el manager (el resto queda igual) |
| `api/__init__.py` | Sirve la carpeta `frontend/` en `/` |
| `requirements.txt` | Se agregó `Flask-Bcrypt` (lo importa `rutas/auth.py` y faltaba) |
| `tests/test_categorias.py` | NUEVO |

## Limitación conocida

El login controla qué pantalla ve el usuario, pero la API todavía no exige token
(el JWT quedó para la HU-16), así que los endpoints no validan sesión.
