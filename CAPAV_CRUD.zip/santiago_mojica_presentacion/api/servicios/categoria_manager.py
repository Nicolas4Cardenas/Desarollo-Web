"""MANAGER de categorías: coordina DOS DAO en una sola funcionalidad.

PARA MOSTRAR AL PROFESOR:
  listar()  -> usa categoria_dao (DAO 1) y producto_dao (DAO 2)
  insertar() -> usa categoria_dao (DAO 1)
"""
import pymysql

from api.dao import categoria_dao, producto_dao
from api.errores import ErrorNegocio

ERRNO_DUPLICADO = 1062  # UNIQUE: ya existe una categoría con ese nombre


def listar():
    """LISTAR: cada categoría con los productos que tiene."""
    # DAO 1: tabla categoria
    categorias = categoria_dao.listar_categorias()
    # DAO 2: tabla producto
    productos = producto_dao.listar_productos()

    # Se combinan los datos de los dos DAO
    nombres_por_categoria = {c["id_categoria"]: [] for c in categorias}
    for p in productos:
        if p["id_categoria"] in nombres_por_categoria:
            nombres_por_categoria[p["id_categoria"]].append(p["nombre"])

    return [
        {
            **c,
            "total_productos": len(nombres_por_categoria[c["id_categoria"]]),
            "productos": nombres_por_categoria[c["id_categoria"]],
        }
        for c in categorias
    ]


def insertar(nombre):
    """INSERTAR: valida el nombre y crea la categoría."""
    if not isinstance(nombre, str) or not nombre.strip():
        raise ErrorNegocio(400, "DATOS_INVALIDOS", "El nombre de la categoría es obligatorio")

    nombre = nombre.strip()
    if len(nombre) > 50:
        raise ErrorNegocio(400, "DATOS_INVALIDOS", "El nombre admite máximo 50 caracteres")

    try:
        # DAO 1: tabla categoria
        return categoria_dao.crear_categoria(nombre)
    except pymysql.IntegrityError as e:
        if e.args and e.args[0] == ERRNO_DUPLICADO:
            raise ErrorNegocio(409, "CATEGORIA_DUPLICADA", "Ya existe una categoría con ese nombre")
        raise
