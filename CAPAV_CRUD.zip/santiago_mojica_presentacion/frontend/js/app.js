import { iniciar } from "./controller.js";

iniciar();
