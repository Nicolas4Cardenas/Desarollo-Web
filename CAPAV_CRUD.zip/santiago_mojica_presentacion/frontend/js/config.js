// La página la sirve la misma app Flask, por eso la ruta es relativa.
export const API_BASE = "/api/v1";
