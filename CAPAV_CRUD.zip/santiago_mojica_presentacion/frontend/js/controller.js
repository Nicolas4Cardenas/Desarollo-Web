// CONTROLADOR: conecta los eventos de la pantalla con el modelo y la vista.
import { Modelo } from "./model.js";
import { Vista } from "./view.js";

const $ = (id) => document.getElementById(id);

async function cargarCategorias() {
  try {
    Vista.pintarCategorias(await Modelo.listarCategorias());
  } catch (e) {
    Vista.mensaje(e.message, "error");
  }
}

async function abrirPanel(usuario) {
  Vista.mostrarCategorias(usuario);
  await cargarCategorias();
}

async function ingresar(evento) {
  evento.preventDefault();
  const { usuario, clave } = Vista.leerLogin();

  if (!usuario || !clave) {
    Vista.errorLogin("Escribe tu usuario y contraseña");
    return;
  }

  Vista.errorLogin("");
  Vista.ocupadoLogin(true);
  try {
    const datos = await Modelo.login(usuario, clave);
    const sesion = { id_usuario: datos.id_usuario, nombre: datos.nombre, rol: datos.rol };
    Modelo.sesion.guardar(sesion);
    await abrirPanel(sesion);
  } catch (e) {
    Vista.errorLogin(e.message);
  } finally {
    Vista.ocupadoLogin(false);
  }
}

async function insertar(evento) {
  evento.preventDefault();
  const nombre = Vista.leerNombreCategoria().trim();

  if (!nombre) {
    Vista.mensaje("Escribe el nombre de la categoría", "error");
    return;
  }

  try {
    await Modelo.insertarCategoria(nombre);
    Vista.limpiarFormularioCategoria();
    Vista.mensaje(`Categoría “${nombre}” creada`, "ok");
    await cargarCategorias();
  } catch (e) {
    Vista.mensaje(e.message, "error");
  }
}

function salir() {
  Modelo.sesion.borrar();
  Vista.mostrarLogin();
}

export function iniciar() {
  $("form-login").addEventListener("submit", ingresar);
  $("form-categoria").addEventListener("submit", insertar);
  $("boton-salir").addEventListener("click", salir);

  const sesion = Modelo.sesion.leer();
  if (sesion) {
    abrirPanel(sesion);
  } else {
    Vista.mostrarLogin();
  }
}
