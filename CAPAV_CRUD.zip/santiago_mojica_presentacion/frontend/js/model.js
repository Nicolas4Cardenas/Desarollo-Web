// MODELO: único lugar que habla con la API (fetch) y guarda la sesión.
import { API_BASE } from "./config.js";

async function llamar(ruta, opciones = {}) {
  let respuesta;
  try {
    respuesta = await fetch(API_BASE + ruta, {
      headers: { "Content-Type": "application/json" },
      ...opciones,
    });
  } catch {
    throw new Error("No se pudo conectar con el servidor");
  }

  let datos = null;
  try {
    datos = await respuesta.json();
  } catch {
    // respuesta sin cuerpo JSON
  }

  if (!respuesta.ok) {
    throw new Error(datos?.error || `Error del servidor (${respuesta.status})`);
  }
  return datos;
}

const CLAVE_SESION = "poli_sesion";

export const Modelo = {
  // --- Login ---
  login(usuario_login, contrasena) {
    return llamar("/login", {
      method: "POST",
      body: JSON.stringify({ usuario_login, contrasena }),
    });
  },

  // --- Categorías: SOLO listar e insertar ---
  listarCategorias() {
    return llamar("/categorias");
  },
  insertarCategoria(nombre) {
    return llamar("/categorias", {
      method: "POST",
      body: JSON.stringify({ nombre }),
    });
  },

  // --- Sesión (solo para recordar quién inició sesión en esta pestaña) ---
  sesion: {
    leer() {
      try {
        return JSON.parse(sessionStorage.getItem(CLAVE_SESION));
      } catch {
        return null;
      }
    },
    guardar(usuario) {
      sessionStorage.setItem(CLAVE_SESION, JSON.stringify(usuario));
    },
    borrar() {
      sessionStorage.removeItem(CLAVE_SESION);
    },
  },
};
