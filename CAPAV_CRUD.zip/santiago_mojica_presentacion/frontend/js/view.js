// VISTA: solo pinta cosas en pantalla. No llama a la API.
const $ = (id) => document.getElementById(id);

function crear(etiqueta, texto, clase) {
  const el = document.createElement(etiqueta);
  if (texto !== undefined) el.textContent = texto; // textContent evita inyección de HTML
  if (clase) el.className = clase;
  return el;
}

export const Vista = {
  // --- cambio de pantalla ---
  mostrarLogin() {
    $("vista-categorias").hidden = true;
    $("vista-login").hidden = false;
    $("form-login").reset();
    this.errorLogin("");
    $("login-usuario").focus();
  },

  mostrarCategorias(usuario) {
    $("vista-login").hidden = true;
    $("vista-categorias").hidden = false;
    $("usuario-activo").textContent = `${usuario.nombre} · ${usuario.rol}`;
    this.mensaje("");
    $("categoria-nombre").focus();
  },

  // --- login ---
  leerLogin() {
    return {
      usuario: $("login-usuario").value.trim(),
      clave: $("login-clave").value,
    };
  },

  errorLogin(texto) {
    const el = $("login-error");
    el.textContent = texto;
    el.hidden = !texto;
  },

  ocupadoLogin(ocupado) {
    $("login-boton").disabled = ocupado;
    $("login-boton").textContent = ocupado ? "Ingresando…" : "Ingresar";
  },

  // --- categorías ---
  leerNombreCategoria() {
    return $("categoria-nombre").value;
  },

  limpiarFormularioCategoria() {
    $("categoria-nombre").value = "";
    $("categoria-nombre").focus();
  },

  mensaje(texto, tipo = "ok") {
    const el = $("mensaje");
    el.textContent = texto;
    el.className = `mensaje ${tipo}`;
    el.hidden = !texto;
  },

  pintarCategorias(categorias) {
    const cuerpo = $("tabla-categorias");
    cuerpo.replaceChildren();

    if (categorias.length === 0) {
      const fila = crear("tr");
      const celda = crear("td", "Aún no hay categorías", "vacio");
      celda.colSpan = 4;
      fila.append(celda);
      cuerpo.append(fila);
      return;
    }

    for (const c of categorias) {
      const fila = crear("tr");
      const celdaTotal = crear("td");
      celdaTotal.append(crear("span", String(c.total_productos), "etiqueta"));

      fila.append(
        crear("td", String(c.id_categoria)),
        crear("td", c.nombre),
        celdaTotal,
        crear("td", c.productos.length ? c.productos.join(", ") : "—", "detalle"),
      );
      cuerpo.append(fila);
    }
  },
};
