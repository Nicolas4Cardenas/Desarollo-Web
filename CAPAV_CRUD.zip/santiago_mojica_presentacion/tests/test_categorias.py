"""Pruebas de login + insertar + listar categorías.

No necesitan MySQL: los DAO se reemplazan por simulaciones.
Ejecutar desde la raíz del proyecto:  python -m pytest -v
"""
import unittest
from unittest.mock import patch

import pymysql

from api import crear_app
from api.rutas.auth import bcrypt


class PruebasCategorias(unittest.TestCase):
    def setUp(self):
        self.cliente = crear_app().test_client()

    # ---------- LISTAR (usa los DOS DAO) ----------
    @patch("api.servicios.categoria_manager.producto_dao")
    @patch("api.servicios.categoria_manager.categoria_dao")
    def test_listar_combina_los_dos_dao(self, categoria_dao, producto_dao):
        categoria_dao.listar_categorias.return_value = [
            {"id_categoria": 1, "nombre": "Bebidas"},
            {"id_categoria": 2, "nombre": "Postres"},
        ]
        producto_dao.listar_productos.return_value = [
            {"id_producto": 10, "nombre": "Gaseosa", "id_categoria": 1},
            {"id_producto": 11, "nombre": "Limonada", "id_categoria": 1},
        ]

        r = self.cliente.get("/api/v1/categorias")

        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.get_json(), [
            {"id_categoria": 1, "nombre": "Bebidas", "total_productos": 2,
             "productos": ["Gaseosa", "Limonada"]},
            {"id_categoria": 2, "nombre": "Postres", "total_productos": 0, "productos": []},
        ])
        categoria_dao.listar_categorias.assert_called_once()   # DAO 1
        producto_dao.listar_productos.assert_called_once()     # DAO 2

    # ---------- INSERTAR ----------
    @patch("api.servicios.categoria_manager.categoria_dao")
    def test_insertar_ok(self, categoria_dao):
        categoria_dao.crear_categoria.return_value = 7

        r = self.cliente.post("/api/v1/categorias", json={"nombre": "  Desayunos  "})

        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.get_json()["id_categoria"], 7)
        categoria_dao.crear_categoria.assert_called_once_with("Desayunos")

    @patch("api.servicios.categoria_manager.categoria_dao")
    def test_insertar_nombre_vacio(self, categoria_dao):
        for cuerpo in ({"nombre": "   "}, {}, {"nombre": 123}):
            r = self.cliente.post("/api/v1/categorias", json=cuerpo)
            self.assertEqual(r.status_code, 400)
        categoria_dao.crear_categoria.assert_not_called()

    @patch("api.servicios.categoria_manager.categoria_dao")
    def test_insertar_duplicada(self, categoria_dao):
        categoria_dao.crear_categoria.side_effect = pymysql.IntegrityError(1062, "Duplicate entry")

        r = self.cliente.post("/api/v1/categorias", json={"nombre": "Bebidas"})

        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.get_json()["codigo"], "CATEGORIA_DUPLICADA")

    # ---------- LOGIN ----------
    @patch("api.rutas.auth.auth_dao")
    def test_login_correcto_e_incorrecto(self, auth_dao):
        hash_ok = bcrypt.generate_password_hash("Admin2026*").decode()
        auth_dao.obtener_usuario_por_login.return_value = {
            "id_usuario": 1, "nombre": "Administrador General",
            "contrasena_hash": hash_ok, "rol": "ADMINISTRADOR",
        }

        ok = self.cliente.post("/api/v1/login", json={"usuario_login": "admin", "contrasena": "Admin2026*"})
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(ok.get_json()["rol"], "ADMINISTRADOR")

        mal = self.cliente.post("/api/v1/login", json={"usuario_login": "admin", "contrasena": "otra"})
        self.assertEqual(mal.status_code, 401)

    @patch("api.rutas.auth.auth_dao")
    def test_login_usuario_inexistente(self, auth_dao):
        auth_dao.obtener_usuario_por_login.return_value = None
        r = self.cliente.post("/api/v1/login", json={"usuario_login": "nadie", "contrasena": "x"})
        self.assertEqual(r.status_code, 401)

    # ---------- PÁGINA ----------
    def test_la_pagina_se_sirve(self):
        r = self.cliente.get("/")
        self.assertEqual(r.status_code, 200)
        self.assertIn("PoliRestaurante", r.get_data(as_text=True))
        r.close()
        js = self.cliente.get("/js/app.js")
        self.assertEqual(js.status_code, 200)
        js.close()


if __name__ == "__main__":
    unittest.main()
