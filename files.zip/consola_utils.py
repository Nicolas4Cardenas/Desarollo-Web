"""Utilidades compartidas por los menús interactivos de consola
(menu_driver.py y menu_orm.py): lectura de datos, tablas y mensajes."""
from datetime import date
from decimal import Decimal

# Estados oficiales de un pedido (los mismos de backend.sql)
ESTADOS = ["PENDIENTE", "EN_PREPARACION", "LISTO", "ENTREGADO", "CANCELADO"]

ANCHO = 74

# Opciones del menú: una por historia de usuario de Nicolas
OPCIONES = [
    ("1", "HU-06  Ver la cola de pedidos pendientes          (rol COCINA)"),
    ("2", "HU-07  Pasar un pedido a EN_PREPARACION            (rol COCINA)"),
    ("3", "HU-08  Marcar un pedido como LISTO                 (rol COCINA)"),
    ("4", "HU-13  Reporte de ventas                           (rol ADMINISTRADOR)"),
    ("5", "HU-14  Reporte de tiempos de preparacion           (rol ADMINISTRADOR)"),
    ("6", "HU-15  Historial: mostrar (todo o por pedido)"),
    ("7", "HU-15  Historial: ver un registro"),
    ("8", "HU-15  Historial: agregar un registro"),
    ("9", "HU-15  Historial: editar un registro      (la base lo rechaza)"),
    ("10", "HU-15  Historial: eliminar un registro    (la base lo rechaza)"),
    ("0", "Cambiar de usuario"),
    ("S", "Salir"),
]


class ErrorNegocio(Exception):
    """Una regla de negocio no se cumple (rol, transicion, dato inexistente...)."""


def mostrar_menu(titulo_menu, usuario):
    print("\n" + "=" * ANCHO)
    print(f"  {titulo_menu}")
    print(f"  Usuario actual: {usuario['id']} - {usuario['login']} ({usuario['rol']})")
    print("=" * ANCHO)
    for clave, texto in OPCIONES:
        print(f"  {clave:>2}. {texto}")
    return input("\nElija una opcion: ").strip().upper()


def encabezado(texto):
    print("\n" + "-" * ANCHO)
    print(f"  {texto}")
    print("-" * ANCHO)


def pausa():
    input("\nPresione Enter para continuar...")


# ---------------------------------------------------------------- entrada
def leer_entero(mensaje, opcional=False):
    while True:
        texto = input(mensaje).strip()
        if texto == "" and opcional:
            return None
        try:
            return int(texto)
        except ValueError:
            print("  Escriba un numero entero.")


def leer_fecha(mensaje, defecto):
    while True:
        texto = input(f"{mensaje} [{defecto}]: ").strip()
        if texto == "":
            return defecto
        try:
            return date.fromisoformat(texto)
        except ValueError:
            print("  Formato invalido. Use AAAA-MM-DD, por ejemplo 2026-10-01.")


def leer_rango():
    """Pide 'desde' y 'hasta'. Por defecto: del dia 1 del mes actual a hoy."""
    hoy = date.today()
    desde = leer_fecha("Desde (AAAA-MM-DD)", hoy.replace(day=1))
    hasta = leer_fecha("Hasta (AAAA-MM-DD)", hoy)
    if hasta < desde:
        raise ErrorNegocio("RANGO_INVALIDO: la fecha 'hasta' es anterior a 'desde'.")
    return desde, hasta


def confirmar(mensaje):
    return input(f"{mensaje} (s/n): ").strip().lower().startswith("s")


def elegir_estado():
    for numero, estado in enumerate(ESTADOS, 1):
        print(f"   {numero}. {estado}")
    while True:
        n = leer_entero("Estado (numero): ")
        if 1 <= n <= len(ESTADOS):
            return ESTADOS[n - 1]
        print("  Elija un numero de la lista.")


# ----------------------------------------------------------------- salida
def formatear(valor):
    if valor is None:
        return "-"
    if isinstance(valor, (bytes, bytearray)):
        return valor.decode("utf-8", "replace")
    if isinstance(valor, bool):
        return "si" if valor else "no"
    if isinstance(valor, (Decimal, float)):
        return f"{valor:.2f}"
    return str(valor)


def imprimir_tabla(filas, titulo=None):
    """Imprime una lista de diccionarios como tabla de texto."""
    if titulo:
        print(f"\n  {titulo}")
    if not filas:
        print("  (sin resultados)")
        return
    columnas = list(filas[0].keys())
    ancho = {
        c: max([len(str(c))] + [len(formatear(f[c])) for f in filas]) for c in columnas
    }
    linea = "  " + "-+-".join("-" * ancho[c] for c in columnas)
    print("  " + " | ".join(str(c).ljust(ancho[c]) for c in columnas))
    print(linea)
    for fila in filas:
        print("  " + " | ".join(formatear(fila[c]).ljust(ancho[c]) for c in columnas))


def imprimir_cola(pedidos, detalle):
    """pedidos: lista de dicts con id_pedido, mesas, fecha_creacion.
    detalle: lista de dicts con id_pedido, producto, cantidad, notas."""
    if not pedidos:
        print("\n  No hay pedidos pendientes.")
        return
    for p in pedidos:
        print(
            f"\n  Pedido #{p['id_pedido']}  |  mesa(s): {formatear(p['mesas'])}"
            f"  |  creado: {p['fecha_creacion']}"
        )
        for d in detalle:
            if d["id_pedido"] == p["id_pedido"]:
                nota = f"   ({d['notas']})" if d["notas"] else ""
                print(f"     - {d['cantidad']} x {d['producto']}{nota}")
