"""MENU INTERACTIVO (consola) - ACCESO DIRECTO A LAS TABLAS CON EL DRIVER.

Usa mysql-connector y SQL escrito a mano, sin procedimientos almacenados y sin ORM.
Cubre las historias de usuario de Nicolas:
  HU-06 cola, HU-07 en preparacion, HU-08 listo, HU-13 ventas, HU-14 tiempos
  y HU-15 historial (mostrar, agregar, editar y eliminar).

Ejecutar desde la carpeta del proyecto:   python menu_driver.py
La base de datos es la misma que se ve en MySQL Workbench (poli_restaurante)."""
import sys
from contextlib import contextmanager
from datetime import timedelta

import mysql.connector

from app.db import get_connection
from consola_utils import (
    ErrorNegocio,
    confirmar,
    elegir_estado,
    encabezado,
    imprimir_cola,
    imprimir_tabla,
    leer_entero,
    leer_rango,
    mostrar_menu,
    pausa,
)

# Transiciones que puede hacer cocina: estado nuevo -> estado actual requerido
ESTADO_PREVIO = {"EN_PREPARACION": "PENDIENTE", "LISTO": "EN_PREPARACION"}


@contextmanager
def conexion():
    """Abre una conexion con cursor de diccionarios y la cierra al terminar."""
    conn = get_connection()
    cur = conn.cursor(dictionary=True)
    try:
        yield conn, cur
    finally:
        cur.close()
        conn.close()


def exigir_rol(cur, id_usuario, rol):
    """El usuario debe existir, estar activo y tener el rol indicado."""
    cur.execute(
        "SELECT r.nombre AS rol FROM usuario u "
        "JOIN rol r ON r.id_rol = u.id_rol "
        "WHERE u.id_usuario = %s AND u.activo = TRUE",
        (id_usuario,),
    )
    fila = cur.fetchone()
    if fila is None or fila["rol"] != rol:
        raise ErrorNegocio(
            f"ACCESO_DENEGADO: esta opcion es solo para el rol {rol}. "
            "Cambie de usuario con la opcion 0."
        )


def comprobar_rol(usuario, rol):
    with conexion() as (conn, cur):
        exigir_rol(cur, usuario["id"], rol)


def elegir_usuario():
    with conexion() as (conn, cur):
        cur.execute(
            "SELECT u.id_usuario AS id, u.usuario_login AS login, r.nombre AS rol "
            "FROM usuario u JOIN rol r ON r.id_rol = u.id_rol "
            "WHERE u.activo = TRUE ORDER BY u.id_usuario"
        )
        usuarios = cur.fetchall()
    if not usuarios:
        raise ErrorNegocio("No hay usuarios activos en la base de datos.")
    imprimir_tabla(usuarios, "Usuarios disponibles (el login con JWT es HU-16, de otro integrante)")
    por_id = {u["id"]: u for u in usuarios}
    while True:
        n = leer_entero("\nId del usuario con el que va a trabajar: ")
        if n in por_id:
            return por_id[n]
        print("  Ese id no esta en la lista.")


# ------------------------------------------------------------- HU-06 a HU-08
def ver_cola(usuario):
    encabezado("HU-06  Cola de pedidos pendientes")
    with conexion() as (conn, cur):
        exigir_rol(cur, usuario["id"], "COCINA")
        cur.execute(
            "SELECT p.id_pedido, p.fecha_creacion, "
            "  (SELECT GROUP_CONCAT(m.numero ORDER BY m.numero SEPARATOR ',') "
            "     FROM pedido_mesa pm JOIN mesa m ON m.id_mesa = pm.id_mesa "
            "    WHERE pm.id_pedido = p.id_pedido) AS mesas "
            "FROM pedido p "
            "WHERE p.estado = 'PENDIENTE' "
            "  AND EXISTS (SELECT 1 FROM detalle_pedido d WHERE d.id_pedido = p.id_pedido) "
            "ORDER BY p.fecha_creacion, p.id_pedido"
        )
        pedidos = cur.fetchall()
        cur.execute(
            "SELECT d.id_pedido, pr.nombre AS producto, d.cantidad, d.notas "
            "FROM detalle_pedido d "
            "JOIN pedido p ON p.id_pedido = d.id_pedido "
            "JOIN producto pr ON pr.id_producto = d.id_producto "
            "WHERE p.estado = 'PENDIENTE' "
            "ORDER BY p.fecha_creacion, p.id_pedido, d.id_detalle"
        )
        detalle = cur.fetchall()
    imprimir_cola(pedidos, detalle)


def cambiar_estado(usuario, nuevo):
    """Cambia el estado de un pedido y registra el historial, en una transaccion."""
    hu = "HU-07" if nuevo == "EN_PREPARACION" else "HU-08"
    encabezado(f"{hu}  Pasar un pedido a {nuevo}")
    comprobar_rol(usuario, "COCINA")
    id_pedido = leer_entero("Numero del pedido: ")
    previo = ESTADO_PREVIO[nuevo]

    with conexion() as (conn, cur):
        try:
            exigir_rol(cur, usuario["id"], "COCINA")
            # FOR UPDATE bloquea la fila: dos cocineros no cambian el mismo pedido a la vez
            cur.execute(
                "SELECT estado FROM pedido WHERE id_pedido = %s FOR UPDATE", (id_pedido,)
            )
            pedido = cur.fetchone()
            if pedido is None:
                raise ErrorNegocio("PEDIDO_NO_EXISTE: el pedido indicado no existe.")
            if pedido["estado"] != previo:
                raise ErrorNegocio(
                    f"TRANSICION_INVALIDA: el pedido esta en {pedido['estado']}; "
                    f"solo se puede pasar a {nuevo} desde {previo}."
                )
            if nuevo == "EN_PREPARACION":
                cur.execute(
                    "SELECT COUNT(*) AS items FROM detalle_pedido WHERE id_pedido = %s",
                    (id_pedido,),
                )
                if cur.fetchone()["items"] == 0:
                    raise ErrorNegocio("PEDIDO_VACIO: el pedido no tiene productos.")

            cur.execute(
                "UPDATE pedido SET estado = %s, fecha_ultima_actualizacion = NOW() "
                "WHERE id_pedido = %s",
                (nuevo, id_pedido),
            )
            cur.execute(
                "INSERT INTO historial_estado (id_pedido, estado, fecha, id_usuario_cambio) "
                "VALUES (%s, %s, NOW(), %s)",
                (id_pedido, nuevo, usuario["id"]),
            )
            conn.commit()  # pedido e historial se guardan juntos
        except Exception:
            conn.rollback()
            raise
    print(f"\n  [OK] El pedido #{id_pedido} paso de {previo} a {nuevo} y quedo en el historial.")


# ------------------------------------------------------------ HU-13 y HU-14
def reporte_ventas(usuario):
    encabezado("HU-13  Reporte de ventas (solo pedidos ENTREGADOS)")
    comprobar_rol(usuario, "ADMINISTRADOR")
    desde, hasta = leer_rango()
    id_categoria = leer_entero("Id de categoria (Enter = todas): ", opcional=True)
    id_producto = leer_entero("Id de producto (Enter = todos): ", opcional=True)

    base = (
        "FROM pedido p "
        "JOIN historial_estado h ON h.id_pedido = p.id_pedido AND h.estado = 'ENTREGADO' "
        "JOIN detalle_pedido d   ON d.id_pedido = p.id_pedido "
        "JOIN producto pr        ON pr.id_producto = d.id_producto "
        "JOIN categoria c        ON c.id_categoria = pr.id_categoria "
        "WHERE p.estado = 'ENTREGADO' "
        "  AND h.fecha >= %s AND h.fecha < %s "
        "  AND (%s IS NULL OR c.id_categoria = %s) "
        "  AND (%s IS NULL OR pr.id_producto = %s) "
    )
    # el rango incluye todo el dia 'hasta': fecha < hasta + 1 dia
    params = (desde, hasta + timedelta(days=1), id_categoria, id_categoria, id_producto, id_producto)

    with conexion() as (conn, cur):
        cur.execute(
            "SELECT COUNT(DISTINCT p.id_pedido) AS pedidos_entregados, "
            "       COALESCE(SUM(d.cantidad), 0) AS productos_vendidos, "
            "       COALESCE(SUM(d.cantidad * d.precio_unitario), 0) AS total_ventas " + base,
            params,
        )
        totales = cur.fetchone()
        cur.execute(
            "SELECT c.nombre AS categoria, SUM(d.cantidad) AS productos_vendidos, "
            "       SUM(d.cantidad * d.precio_unitario) AS total_ventas "
            + base
            + "GROUP BY c.id_categoria, c.nombre ORDER BY total_ventas DESC",
            params,
        )
        por_categoria = cur.fetchall()
        cur.execute(
            "SELECT pr.nombre AS producto, c.nombre AS categoria, "
            "       SUM(d.cantidad) AS unidades_vendidas, "
            "       SUM(d.cantidad * d.precio_unitario) AS total_ventas "
            + base
            + "GROUP BY pr.id_producto, pr.nombre, c.nombre ORDER BY total_ventas DESC",
            params,
        )
        por_producto = cur.fetchall()

    print(f"\n  Periodo: {desde} a {hasta}")
    imprimir_tabla([totales], "Totales")
    imprimir_tabla(por_categoria, "Por categoria")
    imprimir_tabla(por_producto, "Por producto")


def reporte_tiempos(usuario):
    encabezado("HU-14  Reporte de tiempos de preparacion")
    comprobar_rol(usuario, "ADMINISTRADOR")
    desde, hasta = leer_rango()

    # Un renglon por pedido (no cancelado) con la primera vez que paso por cada estado
    base = (
        "SELECT p.id_pedido, "
        "  MIN(CASE WHEN h.estado = 'PENDIENTE'      THEN h.fecha END) AS t_creado, "
        "  MIN(CASE WHEN h.estado = 'EN_PREPARACION' THEN h.fecha END) AS t_prep, "
        "  MIN(CASE WHEN h.estado = 'LISTO'          THEN h.fecha END) AS t_listo, "
        "  MIN(CASE WHEN h.estado = 'ENTREGADO'      THEN h.fecha END) AS t_entregado "
        "FROM pedido p JOIN historial_estado h ON h.id_pedido = p.id_pedido "
        "WHERE p.estado <> 'CANCELADO' "
        "  AND p.fecha_creacion >= %s AND p.fecha_creacion < %s "
        "GROUP BY p.id_pedido"
    )
    params = (desde, hasta + timedelta(days=1))

    with conexion() as (conn, cur):
        cur.execute(
            "SELECT id_pedido, "
            "  TIMESTAMPDIFF(SECOND, t_creado, t_prep)      / 60 AS min_en_cola, "
            "  TIMESTAMPDIFF(SECOND, t_prep,  t_listo)      / 60 AS min_preparacion, "
            "  TIMESTAMPDIFF(SECOND, t_listo, t_entregado)  / 60 AS min_espera_entrega, "
            "  TIMESTAMPDIFF(SECOND, t_creado, t_entregado) / 60 AS min_total "
            "FROM (" + base + ") t ORDER BY t_creado, id_pedido",
            params,
        )
        por_pedido = cur.fetchall()
        cur.execute(
            "SELECT COUNT(t_listo) AS pedidos_preparados, "
            "  ROUND(AVG(TIMESTAMPDIFF(SECOND, t_creado, t_prep))     / 60, 2) AS prom_en_cola, "
            "  ROUND(AVG(TIMESTAMPDIFF(SECOND, t_prep,  t_listo))     / 60, 2) AS prom_preparacion, "
            "  ROUND(AVG(TIMESTAMPDIFF(SECOND, t_listo, t_entregado)) / 60, 2) AS prom_espera_entrega, "
            "  ROUND(AVG(TIMESTAMPDIFF(SECOND, t_creado, t_entregado))/ 60, 2) AS prom_total "
            "FROM (" + base + ") t",
            params,
        )
        promedio = cur.fetchone()

    print(f"\n  Periodo: {desde} a {hasta}   (tiempos en minutos)")
    imprimir_tabla(por_pedido, "Por pedido (un '-' significa que aun no llega a ese estado)")
    imprimir_tabla([promedio], "Promedio del periodo")


# ----------------------------------------------------------------- HU-15
def historial_mostrar(usuario):
    encabezado("HU-15  Historial de estados: mostrar")
    id_pedido = leer_entero("Numero de pedido (Enter = todo el historial): ", opcional=True)
    with conexion() as (conn, cur):
        if id_pedido is None:
            cur.execute("SELECT * FROM historial_estado ORDER BY fecha, id_historial")
        else:
            cur.execute(
                "SELECT * FROM historial_estado WHERE id_pedido = %s "
                "ORDER BY fecha, id_historial",
                (id_pedido,),
            )
        filas = cur.fetchall()
    imprimir_tabla(filas, "Historial")


def historial_ver(usuario):
    encabezado("HU-15  Historial de estados: ver un registro")
    id_historial = leer_entero("Id del registro: ")
    with conexion() as (conn, cur):
        cur.execute("SELECT * FROM historial_estado WHERE id_historial = %s", (id_historial,))
        fila = cur.fetchone()
    if fila is None:
        raise ErrorNegocio("Registro no encontrado.")
    imprimir_tabla([fila], "Registro")


def historial_agregar(usuario):
    encabezado("HU-15  Historial de estados: agregar un registro")
    id_pedido = leer_entero("Numero del pedido: ")
    print("Estado del registro:")
    estado = elegir_estado()
    if estado == "ENTREGADO" and not confirmar(
        "  Aviso: un ENTREGADO manual cuenta doble en los reportes de ventas. Continuar?"
    ):
        print("  Cancelado.")
        return
    with conexion() as (conn, cur):
        try:
            cur.execute("SELECT 1 FROM pedido WHERE id_pedido = %s", (id_pedido,))
            if cur.fetchone() is None:
                raise ErrorNegocio("PEDIDO_NO_EXISTE: el pedido indicado no existe.")
            cur.execute(
                "INSERT INTO historial_estado (id_pedido, estado, id_usuario_cambio) "
                "VALUES (%s, %s, %s)",
                (id_pedido, estado, usuario["id"]),
            )
            conn.commit()
            cur.execute(
                "SELECT * FROM historial_estado WHERE id_historial = %s", (cur.lastrowid,)
            )
            nuevo = cur.fetchone()
        except Exception:
            conn.rollback()
            raise
    print("\n  [OK] Registro agregado:")
    imprimir_tabla([nuevo])


def historial_editar(usuario):
    encabezado("HU-15  Historial de estados: editar (inmutable, RNF-11)")
    id_historial = leer_entero("Id del registro a editar: ")
    with conexion() as (conn, cur):
        cur.execute("SELECT * FROM historial_estado WHERE id_historial = %s", (id_historial,))
        if cur.fetchone() is None:
            raise ErrorNegocio("Registro no encontrado.")
        print("Nuevo estado que se intentara poner:")
        nuevo = elegir_estado()
        print(f"\n  Ejecutando: UPDATE historial_estado SET estado = '{nuevo}' "
              f"WHERE id_historial = {id_historial}")
        try:
            cur.execute(
                "UPDATE historial_estado SET estado = %s WHERE id_historial = %s",
                (nuevo, id_historial),
            )
        except mysql.connector.Error as e:
            print(f"\n  [RECHAZADO POR LA BASE DE DATOS] {e.msg}")
            print("  El historial es inmutable: un trigger impide editarlo.")
        else:
            print("\n  Aviso: la base NO rechazo el cambio (faltaria el trigger).")
            print("  Por seguridad este menu no guarda ediciones del historial.")
        finally:
            conn.rollback()  # nunca se guarda una edicion del historial


def historial_eliminar(usuario):
    encabezado("HU-15  Historial de estados: eliminar (inmutable, RNF-11)")
    id_historial = leer_entero("Id del registro a eliminar: ")
    with conexion() as (conn, cur):
        cur.execute("SELECT * FROM historial_estado WHERE id_historial = %s", (id_historial,))
        if cur.fetchone() is None:
            raise ErrorNegocio("Registro no encontrado.")
        print(f"\n  Ejecutando: DELETE FROM historial_estado WHERE id_historial = {id_historial}")
        try:
            cur.execute("DELETE FROM historial_estado WHERE id_historial = %s", (id_historial,))
        except mysql.connector.Error as e:
            print(f"\n  [RECHAZADO POR LA BASE DE DATOS] {e.msg}")
            print("  El historial es inmutable: un trigger impide borrarlo.")
        else:
            print("\n  Aviso: la base NO rechazo el borrado (faltaria el trigger).")
            print("  Por seguridad este menu no guarda borrados del historial.")
        finally:
            conn.rollback()  # nunca se guarda un borrado del historial


# ------------------------------------------------------------------ menu
def main():
    print("MENU INTERACTIVO - ACCESO CON DRIVER (mysql-connector)")
    print("Conectando a MySQL...")
    try:
        usuario = elegir_usuario()
    except mysql.connector.Error as e:
        print(f"\n[X] No se pudo conectar a MySQL: {e.msg}")
        print("    Revise que MySQL este encendido, que backend.sql este cargado y el archivo .env.")
        return 1
    except ErrorNegocio as e:
        print(f"\n[X] {e}")
        return 1

    acciones = {
        "1": lambda: ver_cola(usuario),
        "2": lambda: cambiar_estado(usuario, "EN_PREPARACION"),
        "3": lambda: cambiar_estado(usuario, "LISTO"),
        "4": lambda: reporte_ventas(usuario),
        "5": lambda: reporte_tiempos(usuario),
        "6": lambda: historial_mostrar(usuario),
        "7": lambda: historial_ver(usuario),
        "8": lambda: historial_agregar(usuario),
        "9": lambda: historial_editar(usuario),
        "10": lambda: historial_eliminar(usuario),
    }

    while True:
        opcion = mostrar_menu("MENU INTERACTIVO - ACCESO CON DRIVER", usuario)
        if opcion == "S":
            print("\nHasta luego.")
            return 0
        try:
            if opcion == "0":
                usuario = elegir_usuario()
                continue
            if opcion not in acciones:
                print("  Opcion no valida.")
            else:
                acciones[opcion]()
        except ErrorNegocio as e:
            print(f"\n  [X] {e}")
        except mysql.connector.Error as e:
            print(f"\n  [X] Error de la base de datos: {e.msg}")
        pausa()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n\nHasta luego.")
        sys.exit(0)
