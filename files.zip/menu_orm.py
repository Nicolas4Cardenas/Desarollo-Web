"""MENU INTERACTIVO (consola) - ACCESO CON ORM (SQLAlchemy).

No hay SQL escrito a mano ni procedimientos almacenados: se trabaja con las clases
de app/models.py (Pedido, DetallePedido, HistorialEstado, ...).
Cubre las historias de usuario de Nicolas:
  HU-06 cola, HU-07 en preparacion, HU-08 listo, HU-13 ventas, HU-14 tiempos
  y HU-15 historial (mostrar, agregar, editar y eliminar).

Ejecutar desde la carpeta del proyecto:   python menu_orm.py
La base de datos es la misma que se ve en MySQL Workbench (poli_restaurante)."""
import sys
from datetime import datetime, time, timedelta

from sqlalchemy import and_, case, distinct, func, literal_column, select, text
from sqlalchemy.exc import DBAPIError, SQLAlchemyError
from sqlalchemy.orm import Session, selectinload

from app.models import (
    Categoria,
    DetallePedido,
    HistorialEstado,
    Pedido,
    Producto,
    Usuario,
)
from app.orm_db import engine
from consola_utils import (
    ErrorNegocio,
    confirmar,
    elegir_estado,
    encabezado,
    imprimir_cola,
    imprimir_tabla,
    leer_entero,
    leer_rango,
    mostrar_menu,
    pausa,
)

# Transiciones que puede hacer cocina: estado nuevo -> estado actual requerido
ESTADO_PREVIO = {"EN_PREPARACION": "PENDIENTE", "LISTO": "EN_PREPARACION"}
SEGUNDOS = literal_column("SECOND")  # unidad que pide TIMESTAMPDIFF


def mensaje_bd(error):
    """Texto del error que devolvio MySQL (por ejemplo el de un trigger)."""
    original = getattr(error, "orig", None)
    return getattr(original, "msg", None) or str(original or error)


def exigir_rol(session, id_usuario, rol):
    """El usuario debe existir, estar activo y tener el rol indicado."""
    u = session.get(Usuario, id_usuario)
    if u is None or not u.activo or u.rol.nombre != rol:
        raise ErrorNegocio(
            f"ACCESO_DENEGADO: esta opcion es solo para el rol {rol}. "
            "Cambie de usuario con la opcion 0."
        )


def comprobar_rol(usuario, rol):
    with Session(engine) as session:
        exigir_rol(session, usuario["id"], rol)


def elegir_usuario():
    with Session(engine) as session:
        usuarios = [
            {"id": u.id_usuario, "login": u.usuario_login, "rol": u.rol.nombre}
            for u in session.scalars(
                select(Usuario).where(Usuario.activo.is_(True)).order_by(Usuario.id_usuario)
            ).all()
        ]
    if not usuarios:
        raise ErrorNegocio("No hay usuarios activos en la base de datos.")
    imprimir_tabla(usuarios, "Usuarios disponibles (el login con JWT es HU-16, de otro integrante)")
    por_id = {u["id"]: u for u in usuarios}
    while True:
        n = leer_entero("\nId del usuario con el que va a trabajar: ")
        if n in por_id:
            return por_id[n]
        print("  Ese id no esta en la lista.")


# ------------------------------------------------------------- HU-06 a HU-08
def ver_cola(usuario):
    encabezado("HU-06  Cola de pedidos pendientes")
    with Session(engine) as session:
        exigir_rol(session, usuario["id"], "COCINA")
        pedidos_orm = session.scalars(
            select(Pedido)
            .where(Pedido.estado == "PENDIENTE", Pedido.detalles.any())
            .options(
                # carga las relaciones por adelantado: no hay una consulta por pedido
                selectinload(Pedido.detalles).selectinload(DetallePedido.producto),
                selectinload(Pedido.mesas),
            )
            .order_by(Pedido.fecha_creacion, Pedido.id_pedido)
        ).all()

        pedidos, detalle = [], []
        for p in pedidos_orm:
            numeros = sorted(m.numero for m in p.mesas)
            pedidos.append(
                {
                    "id_pedido": p.id_pedido,
                    "fecha_creacion": p.fecha_creacion,
                    "mesas": ",".join(str(n) for n in numeros) or None,
                }
            )
            for d in p.detalles:
                detalle.append(
                    {
                        "id_pedido": p.id_pedido,
                        "producto": d.producto.nombre,
                        "cantidad": d.cantidad,
                        "notas": d.notas,
                    }
                )
    imprimir_cola(pedidos, detalle)


def cambiar_estado(usuario, nuevo):
    """Cambia el estado de un pedido y registra el historial, en una transaccion."""
    hu = "HU-07" if nuevo == "EN_PREPARACION" else "HU-08"
    encabezado(f"{hu}  Pasar un pedido a {nuevo}")
    comprobar_rol(usuario, "COCINA")
    id_pedido = leer_entero("Numero del pedido: ")
    previo = ESTADO_PREVIO[nuevo]

    with Session(engine) as session:
        exigir_rol(session, usuario["id"], "COCINA")
        # with_for_update() = SELECT ... FOR UPDATE: bloquea la fila durante la transaccion
        pedido = session.scalars(
            select(Pedido).where(Pedido.id_pedido == id_pedido).with_for_update()
        ).one_or_none()
        if pedido is None:
            raise ErrorNegocio("PEDIDO_NO_EXISTE: el pedido indicado no existe.")
        if pedido.estado != previo:
            raise ErrorNegocio(
                f"TRANSICION_INVALIDA: el pedido esta en {pedido.estado}; "
                f"solo se puede pasar a {nuevo} desde {previo}."
            )
        if nuevo == "EN_PREPARACION":
            items = session.scalar(
                select(func.count())
                .select_from(DetallePedido)
                .where(DetallePedido.id_pedido == id_pedido)
            )
            if items == 0:
                raise ErrorNegocio("PEDIDO_VACIO: el pedido no tiene productos.")

        pedido.estado = nuevo
        pedido.fecha_ultima_actualizacion = func.now()
        session.add(
            HistorialEstado(
                id_pedido=id_pedido,
                estado=nuevo,
                fecha=func.now(),
                id_usuario_cambio=usuario["id"],
            )
        )
        session.commit()  # pedido e historial se guardan juntos
    print(f"\n  [OK] El pedido #{id_pedido} paso de {previo} a {nuevo} y quedo en el historial.")


# ------------------------------------------------------------ HU-13 y HU-14
def limites(desde, hasta):
    """(inicio, fin_exclusivo): el rango incluye todo el dia 'hasta'."""
    inicio = datetime.combine(desde, time.min)
    fin = datetime.combine(hasta + timedelta(days=1), time.min)
    return inicio, fin


def reporte_ventas(usuario):
    encabezado("HU-13  Reporte de ventas (solo pedidos ENTREGADOS)")
    comprobar_rol(usuario, "ADMINISTRADOR")
    desde, hasta = leer_rango()
    id_categoria = leer_entero("Id de categoria (Enter = todas): ", opcional=True)
    id_producto = leer_entero("Id de producto (Enter = todos): ", opcional=True)
    inicio, fin = limites(desde, hasta)

    # Solo pedidos ENTREGADOS cuya fecha de entrega cae en el rango
    condiciones = [
        Pedido.estado == "ENTREGADO",
        HistorialEstado.fecha >= inicio,
        HistorialEstado.fecha < fin,
    ]
    if id_categoria is not None:
        condiciones.append(Categoria.id_categoria == id_categoria)
    if id_producto is not None:
        condiciones.append(Producto.id_producto == id_producto)

    def consulta(*columnas):
        """Misma base (joins + condiciones) para los tres resultados."""
        return (
            select(*columnas)
            .select_from(Pedido)
            .join(
                HistorialEstado,
                and_(
                    HistorialEstado.id_pedido == Pedido.id_pedido,
                    HistorialEstado.estado == "ENTREGADO",
                ),
            )
            .join(DetallePedido, DetallePedido.id_pedido == Pedido.id_pedido)
            .join(Producto, Producto.id_producto == DetallePedido.id_producto)
            .join(Categoria, Categoria.id_categoria == Producto.id_categoria)
            .where(*condiciones)
        )

    unidades = func.sum(DetallePedido.cantidad)
    ventas = func.sum(DetallePedido.cantidad * DetallePedido.precio_unitario)

    with Session(engine) as session:
        totales = session.execute(
            consulta(
                func.count(distinct(Pedido.id_pedido)).label("pedidos_entregados"),
                func.coalesce(unidades, 0).label("productos_vendidos"),
                func.coalesce(ventas, 0).label("total_ventas"),
            )
        ).one()
        por_categoria = session.execute(
            consulta(
                Categoria.nombre.label("categoria"),
                unidades.label("productos_vendidos"),
                ventas.label("total_ventas"),
            )
            .group_by(Categoria.id_categoria, Categoria.nombre)
            .order_by(ventas.desc())
        ).all()
        por_producto = session.execute(
            consulta(
                Producto.nombre.label("producto"),
                Categoria.nombre.label("categoria"),
                unidades.label("unidades_vendidas"),
                ventas.label("total_ventas"),
            )
            .group_by(Producto.id_producto, Producto.nombre, Categoria.nombre)
            .order_by(ventas.desc())
        ).all()

    print(f"\n  Periodo: {desde} a {hasta}")
    imprimir_tabla([dict(totales._mapping)], "Totales")
    imprimir_tabla([dict(f._mapping) for f in por_categoria], "Por categoria")
    imprimir_tabla([dict(f._mapping) for f in por_producto], "Por producto")


def reporte_tiempos(usuario):
    encabezado("HU-14  Reporte de tiempos de preparacion")
    comprobar_rol(usuario, "ADMINISTRADOR")
    desde, hasta = leer_rango()
    inicio, fin = limites(desde, hasta)

    def primera_vez(estado):
        """Primera fecha en que el pedido paso por ese estado."""
        return func.min(case((HistorialEstado.estado == estado, HistorialEstado.fecha)))

    # Un renglon por pedido (no cancelado) con la primera vez que paso por cada estado
    t = (
        select(
            Pedido.id_pedido.label("id_pedido"),
            primera_vez("PENDIENTE").label("t_creado"),
            primera_vez("EN_PREPARACION").label("t_prep"),
            primera_vez("LISTO").label("t_listo"),
            primera_vez("ENTREGADO").label("t_entregado"),
        )
        .select_from(Pedido)
        .join(HistorialEstado, HistorialEstado.id_pedido == Pedido.id_pedido)
        .where(
            Pedido.estado != "CANCELADO",
            Pedido.fecha_creacion >= inicio,
            Pedido.fecha_creacion < fin,
        )
        .group_by(Pedido.id_pedido)
        .subquery("t")
    )

    def segundos(desde_col, hasta_col):
        return func.timestampdiff(SEGUNDOS, desde_col, hasta_col)

    with Session(engine) as session:
        por_pedido = session.execute(
            select(
                t.c.id_pedido,
                (segundos(t.c.t_creado, t.c.t_prep) / 60).label("min_en_cola"),
                (segundos(t.c.t_prep, t.c.t_listo) / 60).label("min_preparacion"),
                (segundos(t.c.t_listo, t.c.t_entregado) / 60).label("min_espera_entrega"),
                (segundos(t.c.t_creado, t.c.t_entregado) / 60).label("min_total"),
            ).order_by(t.c.t_creado, t.c.id_pedido)
        ).all()
        promedio = session.execute(
            select(
                func.count(t.c.t_listo).label("pedidos_preparados"),
                func.round(func.avg(segundos(t.c.t_creado, t.c.t_prep)) / 60, 2).label(
                    "prom_en_cola"
                ),
                func.round(func.avg(segundos(t.c.t_prep, t.c.t_listo)) / 60, 2).label(
                    "prom_preparacion"
                ),
                func.round(func.avg(segundos(t.c.t_listo, t.c.t_entregado)) / 60, 2).label(
                    "prom_espera_entrega"
                ),
                func.round(func.avg(segundos(t.c.t_creado, t.c.t_entregado)) / 60, 2).label(
                    "prom_total"
                ),
            )
        ).one()

    print(f"\n  Periodo: {desde} a {hasta}   (tiempos en minutos)")
    imprimir_tabla(
        [dict(f._mapping) for f in por_pedido],
        "Por pedido (un '-' significa que aun no llega a ese estado)",
    )
    imprimir_tabla([dict(promedio._mapping)], "Promedio del periodo")


# ----------------------------------------------------------------- HU-15
def a_dict(h):
    return {
        "id_historial": h.id_historial,
        "id_pedido": h.id_pedido,
        "estado": h.estado,
        "fecha": h.fecha,
        "id_usuario_cambio": h.id_usuario_cambio,
    }


def historial_mostrar(usuario):
    encabezado("HU-15  Historial de estados: mostrar")
    id_pedido = leer_entero("Numero de pedido (Enter = todo el historial): ", opcional=True)
    consulta = select(HistorialEstado).order_by(
        HistorialEstado.fecha, HistorialEstado.id_historial
    )
    if id_pedido is not None:
        consulta = consulta.where(HistorialEstado.id_pedido == id_pedido)
    with Session(engine) as session:
        filas = [a_dict(h) for h in session.scalars(consulta).all()]
    imprimir_tabla(filas, "Historial")


def historial_ver(usuario):
    encabezado("HU-15  Historial de estados: ver un registro")
    id_historial = leer_entero("Id del registro: ")
    with Session(engine) as session:
        registro = session.get(HistorialEstado, id_historial)
        if registro is None:
            raise ErrorNegocio("Registro no encontrado.")
        fila = a_dict(registro)
    imprimir_tabla([fila], "Registro")


def historial_agregar(usuario):
    encabezado("HU-15  Historial de estados: agregar un registro")
    id_pedido = leer_entero("Numero del pedido: ")
    print("Estado del registro:")
    estado = elegir_estado()
    if estado == "ENTREGADO" and not confirmar(
        "  Aviso: un ENTREGADO manual cuenta doble en los reportes de ventas. Continuar?"
    ):
        print("  Cancelado.")
        return
    with Session(engine) as session:
        if session.get(Pedido, id_pedido) is None:
            raise ErrorNegocio("PEDIDO_NO_EXISTE: el pedido indicado no existe.")
        registro = HistorialEstado(
            id_pedido=id_pedido, estado=estado, id_usuario_cambio=usuario["id"]
        )
        session.add(registro)
        session.commit()
        session.refresh(registro)  # vuelve a leer la fila para traer id_historial y fecha
        fila = a_dict(registro)
    print("\n  [OK] Registro agregado:")
    imprimir_tabla([fila])


def historial_editar(usuario):
    encabezado("HU-15  Historial de estados: editar (inmutable, RNF-11)")
    id_historial = leer_entero("Id del registro a editar: ")
    with Session(engine) as session:
        registro = session.get(HistorialEstado, id_historial)
        if registro is None:
            raise ErrorNegocio("Registro no encontrado.")
        print("Nuevo estado que se intentara poner (distinto al actual):")
        nuevo = elegir_estado()
        if nuevo == registro.estado:
            print("\n  Elija un estado distinto del actual para que se genere el UPDATE.")
            return
        print(f"\n  Ejecutando: registro.estado = '{nuevo}'; session.flush()   (genera un UPDATE)")
        try:
            registro.estado = nuevo
            session.flush()
        except DBAPIError as e:
            print(f"\n  [RECHAZADO POR LA BASE DE DATOS] {mensaje_bd(e)}")
            print("  El historial es inmutable: un trigger impide editarlo.")
        else:
            print("\n  Aviso: la base NO rechazo el cambio (faltaria el trigger).")
            print("  Por seguridad este menu no guarda ediciones del historial.")
        finally:
            session.rollback()  # nunca se guarda una edicion del historial


def historial_eliminar(usuario):
    encabezado("HU-15  Historial de estados: eliminar (inmutable, RNF-11)")
    id_historial = leer_entero("Id del registro a eliminar: ")
    with Session(engine) as session:
        registro = session.get(HistorialEstado, id_historial)
        if registro is None:
            raise ErrorNegocio("Registro no encontrado.")
        print("\n  Ejecutando: session.delete(registro); session.flush()   (genera un DELETE)")
        try:
            session.delete(registro)
            session.flush()
        except DBAPIError as e:
            print(f"\n  [RECHAZADO POR LA BASE DE DATOS] {mensaje_bd(e)}")
            print("  El historial es inmutable: un trigger impide borrarlo.")
        else:
            print("\n  Aviso: la base NO rechazo el borrado (faltaria el trigger).")
            print("  Por seguridad este menu no guarda borrados del historial.")
        finally:
            session.rollback()  # nunca se guarda un borrado del historial


# ------------------------------------------------------------------ menu
def main():
    print("MENU INTERACTIVO - ACCESO CON ORM (SQLAlchemy)")
    print("Conectando a MySQL...")
    try:
        with engine.connect() as conexion:
            conexion.execute(text("SELECT 1"))
        usuario = elegir_usuario()
    except SQLAlchemyError as e:
        print(f"\n[X] No se pudo conectar a MySQL: {mensaje_bd(e)}")
        print("    Revise que MySQL este encendido, que backend.sql este cargado y el archivo .env.")
        return 1
    except ErrorNegocio as e:
        print(f"\n[X] {e}")
        return 1

    acciones = {
        "1": lambda: ver_cola(usuario),
        "2": lambda: cambiar_estado(usuario, "EN_PREPARACION"),
        "3": lambda: cambiar_estado(usuario, "LISTO"),
        "4": lambda: reporte_ventas(usuario),
        "5": lambda: reporte_tiempos(usuario),
        "6": lambda: historial_mostrar(usuario),
        "7": lambda: historial_ver(usuario),
        "8": lambda: historial_agregar(usuario),
        "9": lambda: historial_editar(usuario),
        "10": lambda: historial_eliminar(usuario),
    }

    while True:
        opcion = mostrar_menu("MENU INTERACTIVO - ACCESO CON ORM", usuario)
        if opcion == "S":
            print("\nHasta luego.")
            return 0
        try:
            if opcion == "0":
                usuario = elegir_usuario()
                continue
            if opcion not in acciones:
                print("  Opcion no valida.")
            else:
                acciones[opcion]()
        except ErrorNegocio as e:
            print(f"\n  [X] {e}")
        except SQLAlchemyError as e:
            print(f"\n  [X] Error de la base de datos: {mensaje_bd(e)}")
        pausa()


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (KeyboardInterrupt, EOFError):
        print("\n\nHasta luego.")
        sys.exit(0)
