# Sistema de Gestión de Pedidos — esqueleto de frontend

Estructura mínima en HTML/CSS/JS puro (sin framework) para arrancar las 3
interfaces descritas en el Diagrama de Arquitectura y conectar ahí el
componente dropdown.

```
.
├── index.html              # punto de entrada / selector de rol (temporal)
├── css/
│   └── styles.css          # tokens de color + estilos del dropdown
├── js/
│   ├── dropdown.js         # componente Dropdown reutilizable (una sola clase)
│   └── api.js              # capa de datos MOCK — reemplazar por fetch() al backend real
└── pages/
    ├── mesero.html         # HU-01 / HU-02 — crear pedido, elegir mesa y categoría
    ├── cocina.html          # HU-06 a HU-08 — cola de pedidos, cambiar estado
    └── administracion.html # HU-09 — gestionar productos por categoría
```

## Cómo probarlo

Los archivos usan `<script type="module">`, así que el navegador los bloquea
si los abres con doble clic (`file://`). Sirve la carpeta con cualquier
servidor estático, por ejemplo:

```bash
npx serve .
# o
python -m http.server 8080
```

Y entra a `http://localhost:PUERTO/index.html`.

## Qué es real y qué es mock

- El **dropdown** (`js/dropdown.js`) es el componente final: accesible
  (roles ARIA `combobox`/`listbox`, navegación con teclado), sin dependencias.
- `js/api.js` es **temporal**: simula mesas, categorías, estados y pedidos en
  memoria mientras no exista el backend (API REST + MySQL). Cada función ya
  devuelve una `Promise`, así que el día que conectes el backend real solo
  cambias el cuerpo de esas funciones por `fetch('/api/...')` — el resto del
  código (las páginas) no se toca.
- El **login por rol** en `index.html` es solo navegación de desarrollo.
  La autenticación real (RF-16) y el cifrado de contraseñas (RNF-05) tienen
  que vivir en el backend, y el control de acceso por rol (RNF-06) debe
  validarse ahí también — no alcanza con esconder los enlaces en el frontend.

## Siguiente paso sugerido

1. Definir los endpoints reales de la API (ya lo pide RNF-08) y documentarlos.
2. Reemplazar `js/api.js` por llamadas `fetch()` a esos endpoints.
3. Repetir el patrón de `mesero.html` para las historias que falten
   (cancelar pedido, marcar entregado, reportes, gestión de mesas/usuarios).
