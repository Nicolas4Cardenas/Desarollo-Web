/**
 * Capa de datos temporal (mock) mientras el backend (API REST + MySQL,
 * ver Diagrama Arquitectura) no está listo.
 *
 * Cada función devuelve una Promise para que el resto del código no cambie
 * el día que esto se reemplace por fetch() real. Ejemplo de reemplazo:
 *
 *   export async function getMesas() {
 *     const res = await fetch('/api/mesas');
 *     if (!res.ok) throw new Error('Error al obtener mesas');
 *     return res.json();
 *   }
 */

const MESAS = [
  { id: 1, label: "Mesa 1", estado: "libre" },
  { id: 2, label: "Mesa 2", estado: "ocupada" },
  { id: 3, label: "Mesa 3", estado: "libre" },
  { id: 4, label: "Mesa 4", estado: "ocupada" },
  { id: 5, label: "Mesa 5", estado: "libre" },
];

const CATEGORIAS = ["Entradas", "Platos fuertes", "Bebidas", "Postres"];

const ESTADOS_PEDIDO = [
  { value: "PENDIENTE", label: "Pendiente", tone: "pendiente" },
  { value: "EN_PREPARACION", label: "En preparación", tone: "preparacion" },
  { value: "LISTO", label: "Listo", tone: "listo" },
];

const PEDIDOS_PENDIENTES = [
  { id: 101, mesa: "Mesa 3", creado: "12:04", items: ["2x Bandeja paisa", "1x Limonada"] },
  { id: 102, mesa: "Mesa 1", creado: "12:11", items: ["1x Ajiaco", "2x Jugo de mora"] },
];

const delay = (ms = 150) => new Promise((r) => setTimeout(r, ms));

export async function getMesas() {
  await delay();
  return MESAS;
}

export async function getCategorias() {
  await delay();
  return CATEGORIAS;
}

export async function getEstadosPedido() {
  await delay();
  return ESTADOS_PEDIDO;
}

export async function getPedidosPendientes() {
  await delay();
  return PEDIDOS_PENDIENTES;
}

// TODO: reemplazar por POST /api/pedidos (RF-01)
export async function crearPedido({ mesaId }) {
  await delay();
  console.log("[mock] crear pedido para mesa", mesaId);
  return { id: Date.now(), mesaId, estado: "PENDIENTE" };
}

// TODO: reemplazar por PATCH /api/pedidos/:id/estado (RF-07, RF-08)
export async function cambiarEstadoPedido(pedidoId, nuevoEstado) {
  await delay();
  console.log("[mock] pedido", pedidoId, "->", nuevoEstado);
  return { id: pedidoId, estado: nuevoEstado };
}
