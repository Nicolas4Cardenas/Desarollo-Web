/**
 * Dropdown accesible y reutilizable.
 * Uso:
 *   new Dropdown(document.getElementById('dd-mesa'), {
 *     label: 'Mesa',
 *     placeholder: 'Selecciona una mesa',
 *     options: [{ label: 'Mesa 1', badge: { tone: 'libre', text: 'libre' } }, ...],
 *     onChange: (opcion) => { ... },
 *   });
 *
 * `options` es la única pieza que cambia entre pantallas (mesa, estado, categoría, rol).
 */
export class Dropdown {
  constructor(root, { label, options, placeholder = "Selecciona una opción", onChange } = {}) {
    this.root = root;
    this.options = options;
    this.onChange = onChange;
    this.selected = null;
    this.activeIndex = -1;
    this.id = "dd-" + Math.random().toString(36).slice(2, 9);
    this.build(label, placeholder);
  }

  build(label, placeholder) {
    this.root.innerHTML = "";

    this.trigger = document.createElement("button");
    this.trigger.type = "button";
    this.trigger.className = "dd-trigger";
    this.trigger.setAttribute("aria-haspopup", "listbox");
    this.trigger.setAttribute("aria-expanded", "false");
    this.trigger.setAttribute("aria-label", label);
    this.trigger.id = this.id + "-trigger";

    this.triggerText = document.createElement("span");
    this.triggerText.className = "dd-trigger-text";
    this.renderTriggerText(placeholder);

    const chevron = document.createElement("span");
    chevron.className = "dd-chevron";
    chevron.innerHTML = "▾";
    chevron.setAttribute("aria-hidden", "true");

    this.trigger.append(this.triggerText, chevron);

    this.list = document.createElement("ul");
    this.list.className = "dd-list";
    this.list.setAttribute("role", "listbox");
    this.list.id = this.id + "-list";
    this.list.hidden = true;
    this.trigger.setAttribute("aria-controls", this.list.id);

    this.options.forEach((opt, i) => {
      const li = document.createElement("li");
      li.className = "dd-option";
      li.setAttribute("role", "option");
      li.dataset.index = i;
      li.id = this.id + "-opt-" + i;
      if (opt.disabled) li.setAttribute("aria-disabled", "true");
      li.append(this.renderOptionLabel(opt));
      li.addEventListener("click", () => !opt.disabled && this.select(i));
      this.list.appendChild(li);
    });

    this.root.append(this.trigger, this.list);

    this.trigger.addEventListener("click", () => this.toggle());
    this.trigger.addEventListener("keydown", (e) => this.onTriggerKeydown(e));
    this.list.addEventListener("keydown", (e) => this.onListKeydown(e));
    document.addEventListener("click", (e) => {
      if (!this.root.contains(e.target)) this.close();
    });
  }

  renderOptionLabel(opt) {
    const wrap = document.createDocumentFragment();
    const text = document.createElement("span");
    text.textContent = opt.label;
    wrap.append(text);
    if (opt.badge) {
      const b = document.createElement("span");
      b.className = "badge " + opt.badge.tone;
      b.textContent = opt.badge.text;
      wrap.append(b);
    }
    return wrap;
  }

  renderTriggerText(placeholder) {
    this.triggerText.innerHTML = "";
    if (!this.selected) {
      const span = document.createElement("span");
      span.className = "placeholder";
      span.textContent = placeholder;
      this.triggerText.append(span);
      return;
    }
    this.triggerText.append(this.renderOptionLabel(this.selected));
  }

  toggle() { this.isOpen ? this.close() : this.open(); }

  open() {
    this.isOpen = true;
    this.list.hidden = false;
    this.trigger.setAttribute("aria-expanded", "true");
    const startIndex = this.options.findIndex((o) => o === this.selected);
    this.setActive(startIndex >= 0 ? startIndex : this.firstEnabledIndex());
    this.list.focus();
  }

  close() {
    this.isOpen = false;
    this.list.hidden = true;
    this.trigger.setAttribute("aria-expanded", "false");
  }

  firstEnabledIndex() {
    return this.options.findIndex((o) => !o.disabled);
  }

  setActive(index) {
    if (index < 0 || index >= this.options.length) return;
    this.activeIndex = index;
    [...this.list.children].forEach((li, i) => li.classList.toggle("is-active", i === index));
    this.list.setAttribute("aria-activedescendant", this.id + "-opt-" + index);
    this.list.children[index]?.scrollIntoView({ block: "nearest" });
  }

  moveActive(delta) {
    let i = this.activeIndex;
    for (let step = 0; step < this.options.length; step++) {
      i = (i + delta + this.options.length) % this.options.length;
      if (!this.options[i].disabled) { this.setActive(i); return; }
    }
  }

  select(index) {
    this.selected = this.options[index];
    [...this.list.children].forEach((li, i) =>
      li.setAttribute("aria-selected", i === index ? "true" : "false")
    );
    this.renderTriggerText();
    this.close();
    this.trigger.focus();
    this.onChange?.(this.selected);
  }

  onTriggerKeydown(e) {
    if (["ArrowDown", "ArrowUp", "Enter", " "].includes(e.key)) {
      e.preventDefault();
      this.open();
    }
  }

  onListKeydown(e) {
    switch (e.key) {
      case "ArrowDown": e.preventDefault(); this.moveActive(1); break;
      case "ArrowUp": e.preventDefault(); this.moveActive(-1); break;
      case "Home": e.preventDefault(); this.setActive(this.firstEnabledIndex()); break;
      case "End": e.preventDefault(); this.setActive(this.options.length - 1); break;
      case "Enter":
      case " ":
        e.preventDefault();
        if (!this.options[this.activeIndex]?.disabled) this.select(this.activeIndex);
        break;
      case "Escape": e.preventDefault(); this.close(); this.trigger.focus(); break;
      case "Tab": this.close(); break;
    }
  }
}
